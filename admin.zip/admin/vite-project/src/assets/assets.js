import add_icon from "./add_icon.png"
import order from "./order.jpeg"
import parcel from "./parcel.png"
import profile from "./profile.png"
import uploadicon from "./uploadicon.jpeg"
import logo from "./logo.png"
export const assets = {
    add_icon,
    order,
    parcel,
    profile,
    uploadicon,
    logo
}