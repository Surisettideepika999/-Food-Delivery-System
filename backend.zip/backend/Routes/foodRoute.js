import express from  "express"
import { addFood, listFood, removeFood } from "../Controllers/foodController.js"
import multer from "multer"

const foodRouter = express.Router();

//image storage engine

const storage = multer.diskStorage({
    destination:"Uploads",
    filename:(req,file,cb)=>{
            return cb(null,`${Date.now()}${file.originalname}`) //callback, date to give unique id to each image
    }
})

const upload=multer({storage:storage})


foodRouter.post("/add",upload.single("Image"),addFood)
foodRouter.get("/list",listFood)
foodRouter.post("/remove",removeFood)



export default foodRouter